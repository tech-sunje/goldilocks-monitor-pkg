#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -n "${JAVA_HOME:-}" ]; then JAVA="$JAVA_HOME/bin/java"; else JAVA=java; fi
exec "$JAVA" "-Dmonitor.config=$BASE/monitor.ini" -cp "$BASE/build/goldilocks-monitor.jar:$BASE/lib/*" monitor.Main "$@"
