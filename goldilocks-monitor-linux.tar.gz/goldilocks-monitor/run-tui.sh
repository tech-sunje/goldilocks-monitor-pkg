#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if [ -n "${JAVA_HOME:-}" ]; then JAVA="$JAVA_HOME/bin/java"; else JAVA=java; fi
unset MONITOR_DB_PASSWORD
if [ -f "$BASE/monitor-tui.ini" ]; then DEFAULT_CONFIG="$BASE/monitor-tui.ini"; else DEFAULT_CONFIG="$BASE/monitor.ini"; fi
if [ "$#" -eq 0 ]; then set -- "$DEFAULT_CONFIG"; elif [ "${1#--}" != "$1" ]; then set -- "$DEFAULT_CONFIG" "$@"; fi
exec "$JAVA" -cp "$BASE/build/goldilocks-monitor.jar:$BASE/lib/*" monitor.TuiMain "$@"
