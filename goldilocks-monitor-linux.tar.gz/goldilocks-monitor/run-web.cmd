@echo off
setlocal
if defined JAVA_HOME (
  set "MONITOR_JAVA=%JAVA_HOME%\bin\java.exe"
) else (
  set "MONITOR_JAVA=java.exe"
)
echo Open the browser at the address printed below. Press Ctrl+C to stop.
"%MONITOR_JAVA%" "-Dmonitor.config=%~dp0monitor.ini" -cp "%~dp0build\goldilocks-monitor.jar;%~dp0lib\*" monitor.Main %*
if errorlevel 1 (
  echo Check Java 8 or later, the INI file, and the configured port.
  pause
)
endlocal
